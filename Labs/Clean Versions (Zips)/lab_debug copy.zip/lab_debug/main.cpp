#include "sketchify.h"

int main() {
	sketchify("given_imgs/in_0.png", "out_ubc.png");
    sketchify("given_imgs/in_1.png", "out_rose.png");
    sketchify("given_imgs/in_2.png", "out_icics.png");
    sketchify("given_imgs/in_3.png", "out_nest.png");
    return 0;
}
